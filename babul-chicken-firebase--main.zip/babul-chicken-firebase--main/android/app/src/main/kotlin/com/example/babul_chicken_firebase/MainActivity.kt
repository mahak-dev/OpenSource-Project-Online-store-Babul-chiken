package com.babul_chicken_firebase.store

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
