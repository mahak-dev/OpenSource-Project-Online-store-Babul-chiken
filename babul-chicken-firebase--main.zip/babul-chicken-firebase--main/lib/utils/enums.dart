enum CarType {
  hatchback,
  sedan,
  suv,
}
enum MobileVerificationState {
  SHOW_MOBILE_FORM_STATE,
  SHOW_OTP_FORM_STATE,
}

enum OrderStatus {
  pending,
  completed,
  cancelled,
}
