import 'package:flutter/material.dart';

class MyColor {
  static const primarycolor = Colors.red;
}
